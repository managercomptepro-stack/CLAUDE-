# NIOXXER

Site de petites annonces de rencontre pour le Cameroun. Bilingue français/anglais, web mobile.

Un utilisateur crée un profil (numéro vérifié par WhatsApp, validation manuelle en back-office), publie jusqu'à 3 annonces actives avec photo, et les visiteurs le contactent via un bouton qui ouvre WhatsApp. Gratuit ; les revenus viennent du boost, qui remonte une annonce en tête du fil de sa ville.

Contexte complet : `docs/DOSSIER-PROJET.md`. Ce fichier ne contient que ce qu'il faut savoir pour écrire du code correct.

---

## Jetons de design — règle non négociable

Toutes les couleurs, polices, rayons, espacements et durées viennent de `public/css/tokens.css`.
**Aucune valeur en dur dans un écran.** Si une valeur manque, on l'ajoute aux jetons, on ne l'écrit pas localement.

Repères : fond `--bg:#100E14`, encre `--ink:#F2EDF3`, accent `--accent:#F0455F`, safran `--saffron:#F5C542`.
Titres en Young Serif, interface en Karla. Rayons 16 px sur les cartes, 999 px sur les pilules.

Le décor animé (masses, motifs, étincelles), la politique de mouvement (`html.calm` + bandeau de reprise),
l'en-tête condensé et la barre d'onglets sont des composants partagés définis dans les jetons.

## Stack

- **Laravel 11**, PHP 8.3
- **PostgreSQL 16** — recherche full-text (`tsvector` + index GIN)
- **Redis** — cache, compteurs, files de jobs
- **Filament v3** — back-office admin
- **Blade + Livewire + Tailwind** — front (pas de SPA, le SEO porte l'acquisition)
- **Cloudflare R2** — stockage images ; **Turnstile** — anti-robot
- Déploiement : VPS Ubuntu, Nginx

Dev local : Laragon en natif (pas de Docker — virtualisation désactivée sur la machine de dev).

## Conventions

- Dépôt `nioxxer`, base `nioxxer`, préfixe Redis `nioxxer:`
- Code, noms de classes, variables et commits **en anglais**
- Textes destinés aux utilisateurs **toujours** dans les fichiers de langue, jamais en dur
- Tests : Pest. Toute règle listée sous « Règles non négociables » doit avoir un test.

---

## Règles non négociables

Ces règles portent des obligations légales ou de sécurité. Ne les contourne pas, ne les assouplis pas, ne les mets pas en commentaire « à réactiver plus tard ». Si une tâche semble les exiger, arrête-toi et signale-le.

### 1. Modération des images — trois sorties, jamais deux

Toute photo passe par le pipeline avant d'être visible. Trois issues :

| Détection | Action |
|---|---|
| **Minorité apparente** au-dessus du seuil | `rejected`. Jamais publiée, jamais mise en file. Notification à l'auteur + alerte admin. |
| **Nudité explicite** (organes génitaux, actes sexuels) | `held`. Non visible tant qu'un humain n'a pas tranché. |
| Tout le reste | `published` immédiatement |

« Tout le reste » inclut explicitement : maillot de bain, tenue moulante, pose suggestive, décolleté, torse nu, photo floue, vocabulaire limite. Ces cas ne sont **pas** mis en attente.

Le rejet sur minorité apparente est **automatique et non révisable dans le flux normal**. Il ne passe pas par la file de modération.

### 2. Un seul modèle de paiement

**Naviguer, contacter, créer un compte, se vérifier et publier sont gratuits.**
Créditer son compte est **optionnel**, uniquement pour la mise en avant.

| Produit | Prix | Effet |
|---|---|---|
| Premium 7 jours | 5 000 F | Bandeau du haut, par annonce |
| Boost 7 jours | 1 000 F | Rang dans le fil de la ville |
| Boost 3 jours | 500 F | Idem, formule d'essai |

Paliers de recharge : 1 000 · 2 000 · 5 000 · 10 000 F.

Règles Premium : **par annonce**, cumulable avec le boost, **arrêt sec à 7 jours sans renouvellement
automatique**, alerte la veille de l'expiration. Le surclassement admin est gratuit et **illimité jusqu'à
retrait manuel**. Si plus de 20 Premium, **rotation aléatoire fixée une fois par session**, pas par requête.
Un compteur d'affichages est visible dans « Mes annonces ».

Aucun écran ne doit suggérer que publier est payant.

### 3. Services sexuels tarifés interdits

Les annonces de services sexuels tarifés (ndolo payant, bizi, massage tarifé, escorte) sont interdites par les CGU. Le filtre textuel est **trilingue : français, anglais, pidgin camerounais**.

Un déclenchement textuel ne bloque pas seul la publication : il augmente le score et abaisse le seuil de mise en attente sur les images de la même annonce.

Motif : art. 294 du Code pénal camerounais — facilitation de la prostitution d'autrui ou partage de son produit, même occasionnel. NIOXXER perçoit de l'argent via le boost, donc les deux branches du texte s'appliquent.

### 4. Âge minimum 18 ans

Contrainte au niveau base sur `users.birthdate`. Pas seulement une validation de formulaire.

### 5. Vérification obligatoire pour publier

Un profil ne peut publier une annonce que si `phone_verified_at` est renseigné. Naviguer et contacter restent libres et anonymes ; **publier ne l'est pas**. C'est le seul ancrage d'identité du système.

### 6. `credit_ledger` en ajout seul

Jamais d'`UPDATE`, jamais de `DELETE`. Bloque-les au niveau du modèle Eloquent. Le solde est `SUM(delta)`, caché dans Redis mais toujours recalculable depuis la table.

### 7. Le numéro WhatsApp n'apparaît jamais dans le HTML

Ni dans le rendu serveur, ni dans un attribut `data-`, ni dans une réponse JSON de listing. Il est assemblé côté serveur au moment du clic, après validation Turnstile et vérification des plafonds.

### 8. Paiement Mobile Money manuel

déclare sa transaction. L'administrateur rapproche et valide.

- `topups.reference` est **unique en base** : une référence ne sert qu'une fois
- Les numéros d'encaissement viennent de `settings`, jamais du code
- Le crédit du ledger n'a lieu qu'après validation humaine
- Chaque validation ou rejet est écrit dans `audit_log`

### 9. Journalisation

Toute décision de modération, tout bannissement, tout ajustement de crédit s'écrit dans `audit_log` avec agent, horodatage, motif, avant/après. C'est la preuve de diligence.

### 10. La vérification est derrière une interface

`VerificationChannel` avec `send(User): string` et `confirm(string $code, string $fromPhone): bool`.

Trois implémentations :
- `WhatsAppManualChannel` — **défaut**. Pas d'API. Génère un code, construit le lien `https://wa.me/237678802447?text=CODE`, et crée une entrée dans la file de vérification que l'admin valide dans Filament.
- `WhatsAppCloudChannel` — Cloud API de Meta, si elle devient accessible
- `SmsChannel` — repli agrégateur local

Le canal actif vient de la configuration. Ne couple jamais du code métier à WhatsApp directement.

**Numéro NIOXXER : +237 678 802 447**, à mettre en configuration, jamais en dur dans le code.

**Règle de sécurité de la validation manuelle :** l'écran Filament affiche côte à côte le **code attendu**, le **numéro déclaré dans le profil**, et l'horodatage. L'admin ne valide que si le numéro expéditeur du message WhatsApp correspond au numéro déclaré. Sans cette comparaison, la vérification ne vaut rien.

Code à usage unique, expiration 15 minutes, 5 tentatives maximum.

---

## Points de conception à respecter

**Classement du fil** — récence + bonus boost + activité récente + photo non floutée. Maximum **3 annonces boostées dans les 10 premiers résultats**, et le boost est cantonné à la ville de l'annonce.

**Élargissement automatique** — si la ville filtrée compte moins de 20 annonces actives, compléter avec les villes voisines et l'afficher explicitement à l'utilisateur.

**Boost** — 3 jours = 500 F, 7 jours = 1 000 F, prix paramétrables depuis Filament. Étiquette « Sponsorisé » obligatoire (loi 2010/021 : toute publicité en ligne doit être identifiable). Remboursement automatique en crédits si l'annonce est retirée pendant la période.

**Crédits** — paliers 1 000 / 2 000 / 5 000 / 10 000 F. Les mises en avant débitent le solde.
Publier ne débite jamais rien.

**Plafonds anti-abus** — bouton de contact : 10 clics/heure/IP, 30/jour/IP. Vérification : 5 tentatives, expiration 15 minutes, restriction au préfixe `+237`.

**Domaine** — nioxxer.com

**Annonces** — 3 actives maximum par profil, expiration à 60 jours, au moins une photo, floutage optionnel.

**Signalements** — 3 signalements d'IP distinctes → dépublication automatique en attente de revue.
Le formulaire propose 7 motifs qualifiés, dont « service tarifé » et « la personne semble mineure ».

**Villes** — 28 villes classées par population, avec recherche. Les quartiers sont propres à chaque ville :
ne jamais afficher les quartiers de Douala pour une autre ville.

**Genres** — 7 valeurs : Femme, Homme, Gay, Lesbienne, Trans, Couples, Autres. Partout : inscription,
profil, filtres.

**Contact** — le bouton ouvre `https://wa.me/237678802447` avec un message pré-rempli.

**Rétention** — compte inactif 24 mois, annonce expirée 90 jours, `contact_clicks` 12 mois, logs 12 mois, `audit_log` et `credit_ledger` 5 ans.

---

## Ce qu'il ne faut pas faire

- Ne pas ajouter de catégories d'annonces (décision produit : les filtres portent la découverte)
- Ne pas ajouter de messagerie interne (le contact passe par WhatsApp)
- Ne pas ajouter de swipe (phase 4 au plus tôt)
- Ne pas demander d'e-mail (le téléphone est l'identifiant unique)
- Ne pas exiger de compte pour naviguer ou contacter
- Ne pas utiliser `localStorage` pour des données métier
- Ne jamais afficher de chiffre inventé (nombre de contacts, multiplicateur de vues) : brancher sur une
  vraie donnée ou ne rien afficher

---

## Modèle de données — ajouts

```sql
promotions                      -- remplace boosts
  id, listing_id, user_id
  kind        varchar(10)       -- premium | boost
  source      varchar(10)       -- paid | admin
  cost        integer           -- 0 si admin
  granted_by  bigint NULL
  starts_at, ends_at NULL       -- NULL = illimité (admin)
  revoked_at NULL, impressions integer DEFAULT 0

settings                        -- prix et paliers, modifiables sans redéploiement
  key varchar(60) PK, value jsonb, updated_by bigint, updated_at
  -- toute modification écrite dans audit_log : c'est de l'argent

quartiers
  id, city_id FK, name, slug
```

`credit_ledger.reason` : `topup`, `boost`, `premium`, `refund_removed`, `admin_adjust`.

## Ordre de construction

1. Socle Laravel + i18n FR/EN + Filament
2. Schéma et modèles
3. Vérification WhatsApp (+ repli SMS)
4. Annonces, photos, pipeline de modération
5. Fil public, filtres, classement
6. Bouton de contact + Turnstile + journalisation
7. Signalements et back-office de modération
8. Crédits, Mobile Money, boost

Ne passe pas à l'étape suivante tant que la précédente n'a pas ses tests.

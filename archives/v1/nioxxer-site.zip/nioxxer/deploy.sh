#!/bin/bash
# ═══════════════════════════════════════════════
#  NIOXXER — Script de déploiement Firebase
# ═══════════════════════════════════════════════
# Ce script déploie le site sur Firebase Hosting.
# Exécutez-le depuis le dossier du projet.
#
# Prérequis : Node.js installé sur votre machine.
# ═══════════════════════════════════════════════

set -e

echo ""
echo "╔═══════════════════════════════════════╗"
echo "║   NIOXXER — Déploiement Firebase      ║"
echo "╚═══════════════════════════════════════╝"
echo ""

# 1. Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé."
    echo "   Téléchargez-le : https://nodejs.org"
    exit 1
fi
echo "✅ Node.js $(node -v) détecté"

# 2. Installer Firebase CLI si nécessaire
if ! command -v firebase &> /dev/null; then
    echo "📦 Installation de Firebase CLI..."
    npm install -g firebase-tools
fi
echo "✅ Firebase CLI $(firebase --version) détecté"

# 3. Connexion Firebase
echo ""
echo "🔐 Connexion à Firebase..."
echo "   (Une fenêtre de navigateur va s'ouvrir)"
echo ""
firebase login

# 4. Déploiement
echo ""
echo "🚀 Déploiement sur Firebase Hosting..."
firebase deploy --only hosting

echo ""
echo "╔═══════════════════════════════════════╗"
echo "║   ✅ Déploiement terminé !            ║"
echo "║                                       ║"
echo "║   🌐 https://nioxxer-cda95.web.app   ║"
echo "║   🌐 https://nioxxer.com (si DNS OK) ║"
echo "╚═══════════════════════════════════════╝"
echo ""
